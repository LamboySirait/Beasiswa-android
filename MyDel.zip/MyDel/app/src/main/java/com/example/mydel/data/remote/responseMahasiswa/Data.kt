package com.example.mydel.data.remote.responseMahasiswa

data class Data(
    val mahasiswa: List<Mahasiswa>
)
