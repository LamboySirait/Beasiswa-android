package com.example.mydel.data.remote.responseLogin

data class Jabatan(
    val struktur_jabatan_id: Int,
    val jabatan: String
)
