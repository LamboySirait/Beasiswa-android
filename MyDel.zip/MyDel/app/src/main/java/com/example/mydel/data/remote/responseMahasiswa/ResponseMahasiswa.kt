package com.example.mydel.data.remote.responseMahasiswa

data class ResponseMahasiswa(
    val result: String,
    val data: Data
)
